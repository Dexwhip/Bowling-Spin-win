import React, { useState } from 'react';

interface AdminLoginProps {
  onLoginSuccess: () => void;
}

const AdminLogin: React.FC<AdminLoginProps> = ({ onLoginSuccess }) => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would be a secure check against a server.
    // For this local-only app, we use a simple hardcoded password.
    if (password === 'winner') {
      onLoginSuccess();
    } else {
      setError('Incorrect password. Please try again.');
      setPassword('');
    }
  };

  return (
    <div className="max-w-sm mx-auto bg-gray-800/60 rounded-xl shadow-2xl p-8 backdrop-blur-lg border border-gray-700 mt-20">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-neon-red" style={{ fontFamily: "'Orbitron', sans-serif" }}>Admin Access</h2>
        <p className="text-gray-300 mt-2">Enter the password to manage the contest.</p>
      </div>
      
      <form onSubmit={handleLogin}>
        <div className="mb-4">
          <label htmlFor="password" className="block text-gray-300 text-sm font-bold mb-2">Password</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className={`w-full bg-gray-900 border ${error ? 'border-red-500' : 'border-gray-600'} rounded-lg py-3 px-4 text-bowling-pin-white leading-tight focus:outline-none focus:bg-gray-800 focus:border-neon-red transition-all duration-300`}
            required
          />
          {error && <p className="text-red-500 text-xs italic mt-2">{error}</p>}
        </div>

        <div className="flex items-center justify-center mt-6">
          <button
            type="submit"
            className="w-full bg-neon-red hover:bg-red-600 text-white font-bold py-3 px-4 rounded-lg focus:outline-none focus:shadow-outline transition-all duration-300 transform hover:scale-105"
          >
            Login
          </button>
        </div>
      </form>
    </div>
  );
};

export default AdminLogin;