import React, { useState } from 'react';

interface SpinnerProps {
  items: string[];
  onWinnerSelected: (winner: string) => void;
}

const colors = [
  '#ef4444', '#1f2937', '#dc2626', '#4b5563', '#b91c1c', 
  '#6b7280', '#991b1b', '#374151', '#f87171', '#111827'
];

const Spinner: React.FC<SpinnerProps> = ({ items, onWinnerSelected }) => {
  const [isSpinning, setIsSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);

  const handleSpin = () => {
    if (isSpinning || items.length < 2) return;

    setIsSpinning(true);
    const winnerIndex = Math.floor(Math.random() * items.length);
    const degreesPerItem = 360 / items.length;
    
    // Calculate target rotation
    // 5 full spins (1800 deg) + random offset within the slice + target slice position
    const randomOffset = Math.random() * degreesPerItem * 0.8 - degreesPerItem * 0.4;
    const targetRotation = 360 * 5 - (winnerIndex * degreesPerItem) + randomOffset;
    
    setRotation(rotation + targetRotation);

    setTimeout(() => {
      onWinnerSelected(items[winnerIndex]);
      setIsSpinning(false);
    }, 8000); // Must match animation duration
  };

  // Handle case with 0 or 1 item to prevent division by zero and weird rendering.
  if (items.length < 2) {
    return (
      <div className="flex flex-col items-center justify-center gap-8 py-8">
        <div className="relative w-96 h-96 md:w-[500px] md:h-[500px]">
          <div className="w-full h-full rounded-full border-8 border-gray-600 bg-gray-700 shadow-2xl flex items-center justify-center">
            <span className="text-2xl text-white font-bold px-4 text-center break-all">{items[0] || 'No Entries'}</span>
          </div>
        </div>
        <button
          disabled
          className="bg-gray-500 text-white font-bold py-4 px-12 rounded-lg cursor-not-allowed"
          style={{ fontFamily: "'Orbitron', sans-serif" }}
        >
          {items.length === 1 ? 'Need More Entries' : 'SPIN THE WHEEL'}
        </button>
      </div>
    );
  }

  const segmentAngle = 360 / items.length;
  const conicGradient = `conic-gradient(${items.map((_, index) => `${colors[index % colors.length]} ${index * segmentAngle}deg ${(index + 1) * segmentAngle}deg`).join(', ')})`;

  // Dynamically adjust text styles based on number of items
  const itemCount = items.length;
  let fontSizeClass = 'text-sm'; // 14px
  let truncationLength = 10;

  if (itemCount > 75) {
      fontSizeClass = 'text-[8px]';
      truncationLength = 6;
  } else if (itemCount > 40) {
      fontSizeClass = 'text-[10px]';
      truncationLength = 8;
  } else if (itemCount > 20) {
      fontSizeClass = 'text-xs'; // 12px
      truncationLength = 9;
  }

  return (
    <div className="flex flex-col items-center justify-center gap-8 py-8">
        <div className="relative w-96 h-96 md:w-[500px] md:h-[500px]">
            {/* Pointer */}
            <div className="absolute -top-4 left-1/2 -translate-x-1/2 z-10" style={{ filter: 'drop-shadow(0 4px 3px rgba(0,0,0,0.4))' }}>
                <div className="w-0 h-0 
                    border-l-[15px] border-l-transparent
                    border-r-[15px] border-r-transparent
                    border-t-[30px] border-t-neon-red">
                </div>
            </div>

            {/* Wheel */}
            <div 
                className="relative w-full h-full transition-transform duration-[8000ms] ease-[cubic-bezier(0.25,1,0.5,1)]"
                style={{ transform: `rotate(${rotation}deg)` }}
            >
                {/* Wheel Background */}
                <div 
                    className="w-full h-full rounded-full border-8 border-gray-600 bg-gray-700 shadow-2xl"
                    style={{ background: conicGradient }}
                />

                {/* Names */}
                <ul className="absolute inset-0 m-0 p-0 list-none">
                    {items.map((item, index) => {
                    const angle = segmentAngle * index + segmentAngle / 2;
                    return (
                        <li
                        key={index}
                        className="absolute top-0 left-0 w-full h-full"
                        style={{ transform: `rotate(${angle}deg)` }}
                        >
                        <div
                            className={`absolute left-1/2 w-1/2 h-full flex items-center justify-center text-white font-bold ${fontSizeClass}`}
                        >
                            <span 
                                style={{ 
                                    display: 'inline-block', 
                                    transform: 'rotate(-90deg)',
                                    whiteSpace: 'nowrap'
                                }}
                            >
                            {item.substring(0, truncationLength)}
                            {item.length > truncationLength ? '...' : ''}
                            </span>
                        </div>
                        </li>
                    );
                    })}
                </ul>
            </div>

            {/* Center circle */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-16 h-16 bg-gray-600 rounded-full border-4 border-gray-500"></div>
        </div>

      <button
        onClick={handleSpin}
        disabled={isSpinning || items.length < 2}
        className="bg-neon-red hover:bg-red-600 text-white font-bold py-4 px-12 rounded-lg focus:outline-none focus:shadow-outline transition-all duration-300 transform hover:scale-105 disabled:bg-gray-500 disabled:cursor-not-allowed disabled:scale-100"
        style={{ fontFamily: "'Orbitron', sans-serif" }}
      >
        {isSpinning ? 'Spinning...' : 'SPIN THE WHEEL'}
      </button>
    </div>
  );
};

export default Spinner;