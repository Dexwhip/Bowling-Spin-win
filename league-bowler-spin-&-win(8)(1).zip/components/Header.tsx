import React from 'react';

interface HeaderProps {
  isAuthenticated: boolean;
}

const Header: React.FC<HeaderProps> = ({ isAuthenticated }) => {
  return (
    <header className="bg-gray-900/50 backdrop-blur-lg border-b border-gray-700 sticky top-0 z-20">
      <nav className="container mx-auto flex items-center justify-between p-4">
        <a href="/#" className="text-xl font-bold text-neon-red" style={{ fontFamily: "'Orbitron', sans-serif" }}>
          Spin & Win
        </a>
        <div>
          {isAuthenticated ? (
            <a 
              href="/#" 
              className="text-gray-300 hover:text-white transition-colors duration-200"
              aria-label="Return to Public Form"
            >
              Public Form
            </a>
          ) : (
            <a 
              href="#/admin" 
              className="text-gray-300 hover:text-white transition-colors duration-200"
              aria-label="Admin Access"
            >
              Admin
            </a>
          )}
        </div>
      </nav>
    </header>
  );
};

export default Header;
