export const firebaseConfig = {

  apiKey: "AIzaSyDbhwJl31xONzcRzIpXpB5VCBMXOaUDlSk",

  authDomain: "bowling-lg-contest.firebaseapp.com",

  projectId: "bowling-lg-contest",

  storageBucket: "bowling-lg-contest.firebasestorage.app",

  messagingSenderId: "250539522581",

  appId: "1:250539522581:web:02b430dc7c97f0fd31ac1c"

};
