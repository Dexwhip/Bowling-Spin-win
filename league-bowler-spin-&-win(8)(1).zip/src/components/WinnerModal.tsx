import React, { useEffect, useState } from 'react';
import { Bowler } from '../types';

interface WinnerModalProps {
  winner: Bowler;
  onClose: () => void;
}

// A memoized component for a single piece of confetti
const ConfettiPiece: React.FC<{ style: React.CSSProperties }> = React.memo(({ style }) => (
    <div className="absolute w-2 h-4" style={style}></div>
));

const WinnerModal: React.FC<WinnerModalProps> = ({ winner, onClose }) => {
    const [confetti, setConfetti] = useState<React.CSSProperties[]>([]);

    useEffect(() => {
        const confettiColors = ['#ef4444', '#f97316', '#eab308', '#84cc16', '#22c55e', '#14b8a6', '#06b6d4', '#3b82f6', '#8b5cf6', '#d946ef'];
        const newConfetti = Array.from({ length: 150 }).map(() => ({
            left: `${Math.random() * 100}%`,
            transform: `rotate(${Math.random() * 360}deg)`,
            backgroundColor: confettiColors[Math.floor(Math.random() * confettiColors.length)],
            animation: `fall ${3 + Math.random() * 3}s ${Math.random() * 2}s linear forwards`,
            opacity: 1,
        }));
        setConfetti(newConfetti);
    }, []);

    return (
        <div 
            className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4 backdrop-blur-sm"
            onClick={onClose}
            aria-modal="true"
            role="dialog"
        >
            <div 
                className="relative bg-gray-800 rounded-2xl shadow-2xl p-8 backdrop-blur-lg border border-gray-700 text-center max-w-md w-full transform transition-all duration-300 scale-100 animate-modal-pop-in overflow-hidden"
                onClick={e => e.stopPropagation()}
            >
                <div className="absolute inset-0 pointer-events-none">
                    {confetti.map((style, index) => (
                        <ConfettiPiece key={index} style={style} />
                    ))}
                </div>

                <div className="relative z-10">
                    <h3 className="text-2xl font-bold text-yellow-400">🎉 CONGRATULATIONS! 🎉</h3>
                    <p className="text-lg text-gray-300 mt-2">The winner of the Publix Gift Card is...</p>
                    <p 
                        className="text-5xl font-extrabold text-white my-6 break-words" 
                        style={{ fontFamily: "'Orbitron', sans-serif", textShadow: '0 0 15px rgba(239, 68, 68, 0.8)' }}
                    >
                        {winner.name}
                    </p>
                    <p className="text-gray-400">{winner.email} - {winner.phone}</p>
                    <button
                        onClick={onClose}
                        className="mt-8 bg-neon-red hover:bg-red-600 text-white font-bold py-3 px-8 rounded-lg focus:outline-none focus:shadow-outline transition-all duration-300 transform hover:scale-105"
                    >
                        Close
                    </button>
                </div>
            </div>
        </div>
    );
};

export default WinnerModal;
