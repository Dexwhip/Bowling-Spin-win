import React, { useState } from 'react';
import { Bowler } from '../types';

interface BowlerFormProps {
  onAddBowler: (bowler: Omit<Bowler, 'id'>) => Promise<boolean>;
}

const BowlerForm: React.FC<BowlerFormProps> = ({ onAddBowler }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [optedIn, setOptedIn] = useState(false);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const [submitted, setSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const validate = (): boolean => {
    const newErrors: { [key: string]: string } = {};
    if (!name.trim()) newErrors.name = 'Name is required';
    if (!email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      newErrors.email = 'Email is invalid';
    }
    if (!phone.trim()) {
        newErrors.phone = 'Phone number is required';
    } else if (!/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/.test(phone)) {
        newErrors.phone = 'Phone number is invalid';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    
    setIsSubmitting(true);
    
    const success = await onAddBowler({ name, email, phone, optedIn });

    if (success) {
      setName('');
      setEmail('');
      setPhone('');
      setOptedIn(false);
      setSubmitted(true);
      setErrors({}); // Clear any previous errors
      
      // Hide the success message after 3 seconds
      setTimeout(() => setSubmitted(false), 3000);
    } else {
      // It's a duplicate entry
      setErrors({ submit: 'This email or phone number has already been entered.' });
      setSubmitted(false);
    }

    setIsSubmitting(false);
  };

  return (
    <div className="max-w-lg mx-auto bg-gray-800/60 rounded-xl shadow-2xl p-8 backdrop-blur-lg border border-gray-700">
      <div className="text-center mb-8">
        <h2 className="text-4xl font-bold text-neon-red" style={{ fontFamily: "'Orbitron', sans-serif" }}>Enter to Win!</h2>
        <p className="text-gray-300 mt-2">A Publix Gift Card for Thanksgiving!</p>
      </div>
      
      {submitted && (
        <div className="bg-green-500/20 border border-green-500 text-green-300 px-4 py-3 rounded-lg relative mb-6" role="alert">
          <strong className="font-bold">Success! </strong>
          <span className="block sm:inline">Your entry has been received. Good luck!</span>
        </div>
      )}

      <form onSubmit={handleSubmit} noValidate>
        <div className="mb-4">
          <label htmlFor="name" className="block text-gray-300 text-sm font-bold mb-2">Full Name</label>
          <input
            type="text"
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className={`w-full bg-gray-900 border ${errors.name ? 'border-red-500' : 'border-gray-600'} rounded-lg py-3 px-4 text-bowling-pin-white leading-tight focus:outline-none focus:bg-gray-800 focus:border-neon-red transition-all duration-300`}
            required
            disabled={isSubmitting}
          />
          {errors.name && <p className="text-red-500 text-xs italic mt-1">{errors.name}</p>}
        </div>
        <div className="mb-4">
          <label htmlFor="email" className="block text-gray-300 text-sm font-bold mb-2">Email Address</label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className={`w-full bg-gray-900 border ${errors.email ? 'border-red-500' : 'border-gray-600'} rounded-lg py-3 px-4 text-bowling-pin-white leading-tight focus:outline-none focus:bg-gray-800 focus:border-neon-red transition-all duration-300`}
            required
            disabled={isSubmitting}
          />
          {errors.email && <p className="text-red-500 text-xs italic mt-1">{errors.email}</p>}
        </div>
        <div className="mb-6">
          <label htmlFor="phone" className="block text-gray-300 text-sm font-bold mb-2">Phone Number</label>
          <input
            type="tel"
            id="phone"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            className={`w-full bg-gray-900 border ${errors.phone ? 'border-red-500' : 'border-gray-600'} rounded-lg py-3 px-4 text-bowling-pin-white leading-tight focus:outline-none focus:bg-gray-800 focus:border-neon-red transition-all duration-300`}
            required
            disabled={isSubmitting}
          />
          {errors.phone && <p className="text-red-500 text-xs italic mt-1">{errors.phone}</p>}
        </div>
        <div className="mb-6">
          <label className="flex items-center text-gray-400">
            <input
              type="checkbox"
              checked={optedIn}
              onChange={(e) => setOptedIn(e.target.checked)}
              className="form-checkbox h-5 w-5 text-neon-red bg-gray-900 border-gray-600 rounded focus:ring-neon-red"
              disabled={isSubmitting}
            />
            <span className="ml-2 text-sm">Opt-in for future communications.</span>
          </label>
        </div>
        
        {errors.submit && (
            <div className="bg-red-500/20 border border-red-500 text-red-300 px-4 py-3 rounded-lg relative mb-6 text-center" role="alert">
                {errors.submit}
            </div>
        )}

        <div className="flex items-center justify-center">
          <button
            type="submit"
            className="w-full bg-neon-red hover:bg-red-600 text-white font-bold py-3 px-4 rounded-lg focus:outline-none focus:shadow-outline transition-all duration-300 transform hover:scale-105 disabled:bg-gray-500 disabled:cursor-not-allowed disabled:scale-100"
            disabled={isSubmitting}
          >
            {isSubmitting ? 'Submitting...' : 'Enter Contest'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default BowlerForm;
